# Proyecto: El Mundo de las TIC

Sitio educativo estático, adaptable a móviles y computadores, desarrollado con HTML, CSS y JavaScript.

## Archivos
- `index.html`: contenido y estructura de todas las secciones.
- `styles.css`: diseño visual adaptable.
- `script.js`: navegación móvil y cuestionario interactivo.

## Verlo en tu computador
1. Descomprime el archivo ZIP.
2. Abre la carpeta `proyecto_mundo_tic`.
3. Haz doble clic en `index.html` para abrir el sitio en el navegador.

## Publicarlo
Puedes subir la carpeta a un servicio de alojamiento estático (por ejemplo, GitHub Pages o Netlify) para obtener una dirección pública.

## Usarlo con Google Sites
Google Sites no importa una carpeta HTML/CSS/JS como un sitio completo. Primero publica esta carpeta en un servicio de alojamiento y luego, en Google Sites, usa **Insertar > Incorporar > Por URL** para insertar la dirección pública. También puedes crear páginas nativas en Google Sites y copiar allí el contenido.

Proyecto educativo de demostración. Revisa y adapta los datos institucionales, autoría y requisitos de tu docente antes de entregar.
