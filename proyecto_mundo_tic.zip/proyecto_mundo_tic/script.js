const menuToggle=document.getElementById("menuToggle");
const nav=document.getElementById("nav");
menuToggle.addEventListener("click",()=>nav.classList.toggle("open"));
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));

const questions=[
 {q:"¿Qué significan las siglas TIC?",o:["Tecnologías de la Información y la Comunicación","Técnicas de Internet y Computación","Tecnologías de Inteligencia Computacional"],a:0,why:"TIC significa Tecnologías de la Información y la Comunicación."},
 {q:"¿Cuál de estas opciones es un ejemplo de inteligencia artificial?",o:["Un cable de red","Un asistente conversacional como ChatGPT","Un interruptor de luz"],a:1,why:"Los asistentes conversacionales utilizan modelos de inteligencia artificial."},
 {q:"¿Qué describe mejor el e-learning?",o:["Comprar productos en línea","Trabajar desde casa","Aprender mediante plataformas y recursos digitales"],a:2,why:"El e-learning utiliza tecnologías digitales para apoyar la enseñanza y el aprendizaje."},
 {q:"¿Qué es el phishing?",o:["Una modalidad de teletrabajo","Un engaño para obtener datos confidenciales","Un programa para editar imágenes"],a:1,why:"El phishing intenta engañar a las personas para que revelen información o ingresen a sitios falsos."},
 {q:"¿Cuál es una buena práctica de seguridad web?",o:["Compartir contraseñas con amigos","Abrir cualquier enlace recibido","Activar la verificación en dos pasos"],a:2,why:"La verificación en dos pasos agrega una capa adicional de protección."}
];
let current=0,score=0,chosen=null;
const questionEl=document.getElementById("question"),optionsEl=document.getElementById("options"),nextBtn=document.getElementById("nextBtn"),feedback=document.getElementById("feedback");
function renderQuestion(){
 const q=questions[current];chosen=null;
 document.getElementById("progressText").textContent=`Pregunta ${current+1} de ${questions.length}`;
 document.getElementById("progressBar").style.width=`${(current+1)/questions.length*100}%`;
 questionEl.textContent=q.q;optionsEl.innerHTML="";feedback.textContent="";nextBtn.disabled=true;
 q.o.forEach((option,i)=>{const b=document.createElement("button");b.className="option";b.textContent=option;b.type="button";b.addEventListener("click",()=>selectOption(i,b));optionsEl.appendChild(b)});
 nextBtn.textContent=current===questions.length-1?"Ver resultado →":"Siguiente →";
}
function selectOption(i,button){
 if(chosen!==null)return;chosen=i;
 [...optionsEl.children].forEach((b,index)=>{b.disabled=true;if(index===questions[current].a)b.classList.add("correct");else if(index===i)b.classList.add("incorrect")});
 if(i===questions[current].a){score++;feedback.textContent="¡Correcto! "+questions[current].why}
 else feedback.textContent="No exactamente. "+questions[current].why;
 nextBtn.disabled=false;
}
nextBtn.addEventListener("click",()=>{if(chosen===null)return;if(current<questions.length-1){current++;renderQuestion()}else showResult()});
function showResult(){
 document.getElementById("quizBox").hidden=true;const box=document.getElementById("resultBox");box.hidden=false;
 document.getElementById("resultTitle").textContent=score===5?"¡Excelente trabajo!":score>=3?"¡Vas por buen camino!":"¡Sigue aprendiendo!";
 document.getElementById("resultText").textContent=`Obtuviste ${score} de ${questions.length} respuestas correctas. ${score===5?"Dominas los conceptos básicos.": "Repasa los temas y vuelve a intentarlo para mejorar tu resultado."}`;
}
document.getElementById("restartBtn").addEventListener("click",()=>{current=0;score=0;document.getElementById("resultBox").hidden=true;document.getElementById("quizBox").hidden=false;renderQuestion()});
renderQuestion();
